/*
  ONE-STOP HOME STORE — Firebase configuration
  ----------------------------------------------
  PREVIEW MODE: leave enabled:false and the website uses a safe local demo.
  LIVE MODE: create a Firebase project, enable Google + Phone authentication,
  create Firestore, then replace the placeholders and set enabled:true.

  Never put a Firebase Admin SDK private key here. Firebase web config values
  are client-side identifiers; Firestore/Auth Security Rules protect the data.
*/
window.PELUMHIE_FIREBASE_CONFIG = {
  enabled: false,
  ownerUid: "REPLACE_WITH_OWNER_FIREBASE_UID",
  config: {
    apiKey: "REPLACE_ME",
    authDomain: "REPLACE_ME.firebaseapp.com",
    projectId: "REPLACE_ME",
    storageBucket: "REPLACE_ME.firebasestorage.app",
    messagingSenderId: "REPLACE_ME",
    appId: "REPLACE_ME"
  }
};

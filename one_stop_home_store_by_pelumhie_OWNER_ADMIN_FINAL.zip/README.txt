ONE-STOP HOME STORE BY PELUMHIE — PROFESSIONAL WEBSITE PACKAGE

WHAT IS INCLUDED
- Mobile-first blue/navy/gold storefront design.
- Home, Products, About Us, Contact pages.
- Customer Account page with email preview authentication plus Google and Phone OTP UI ready for Firebase.
- Private buyer-to-owner chat page and Owner Inbox architecture.
- Customer reviews/comments with star ratings.
- Product search that passes the customer's exact search words to Unsplash, Pexels or Pixabay.
- Product request form with description + image upload validation.
- Brand image-search gallery.
- Luxury Shoes category.
- Professional flyer embedded in the Home page.
- Privacy Policy, Terms & Conditions, Returns & Refunds and 404 pages.
- Netlify security headers template.
- Firebase Firestore and Storage security rules for live private chat, requests and reviews.

IMPORTANT ABOUT LIVE LOGIN / CHAT
This ZIP is a static front-end package until a backend is connected. The preview has a safe browser-only demo session so the interface can be tested without storing real passwords. Google sign-in, phone OTP, cross-device accounts, truly private buyer/owner chat and shared reviews become live only after Firebase is configured.

FIREBASE LIVE SETUP
1. Create a Firebase project and register a Web App.
2. Enable Authentication providers: Email/Password, Google and Phone.
3. Create Cloud Firestore and Cloud Storage.
4. Copy the Firebase web config into firebase-config.js and set enabled:true.
5. Create the owner's Firebase account, copy the owner's Auth UID into ownerUid.
6. Replace REPLACE_WITH_OWNER_FIREBASE_UID in firebase-rules.txt and firebase-storage-rules.txt with the same UID.
7. Publish the Firestore rules and Storage rules.
8. For Phone Authentication, configure the authorised domains and reCAPTCHA as required by Firebase.
9. Deploy the website over HTTPS. Do not use a Firebase Admin private key in this website.
10. Test a customer account, a customer chat, an owner reply and a customer review before public launch.

SECURITY NOTES
- The static preview cannot provide server-side privacy. Do not treat localStorage/sessionStorage as secure storage.
- The live private chat is designed around /chats/{userId}/messages and owner-only access enforced by Firestore rules.
- Never collect bank PINs, card PINs, OTPs or passwords through chat.
- Use a trusted payment gateway for payments rather than storing card information in this website.
- Security headers are included for Netlify deployment; review CSP if you add other third-party services.

PERFORMANCE
The large hero collage and flyer were converted to optimized JPEGs so the website loads faster on phones. Product images are local and modest in size.

BRAND / IMAGE NOTICE
Brand names are request categories and do not guarantee stock, authenticity, price or availability. Customers should confirm the exact product with the store. Image-search websites are external services and have their own copyright and usage terms.

BUSINESS DETAILS
ONE-STOP HOME STORE by Pelumhie
Your home, our priority.
Delivery: Iyin & Ado Ekiti
Phone: 08104204939
Enquiries: 08109589008
Email: tobbyjay80@gmail.com
WhatsApp: https://wa.me/2348104204939
WhatsApp Community: https://chat.whatsapp.com/EBeHHT4LcAGFJmHmdI9ZBA?s=cl&p=a&mlu=4&ilr=4

REAL PRODUCT CATALOGUE UPDATE
-----------------------------
44 real product images supplied in the customer's ZIP were added without replacing the former design.
Images were optimized for faster phone loading.
Shorthand prices such as 14k were converted to full Naira amounts such as ₦14,000.
No exact price was invented: products without a clear price show Ask the store or Price varies.
The Products page now has local product search and category filtering, with Order/Ask and View Image actions.
The Home page includes a compact selection of the supplied catalogue.


OWNER PRODUCT MANAGEMENT
------------------------
The customer-facing design was not replaced. A separate private owner dashboard was added:
- owner-dashboard.html
- Only the Firebase account whose UID equals ownerUid can publish/edit/delete products.
- Pelumhie is the designated website owner in the setup; the actual Firebase Auth UID must be placed in firebase-config.js after the owner account is created.
- Owner can enter product name, price (14k/14000/₦14,000), category, properties/specifications, description, availability and a product image.
- New products are stored in Firestore and images in Firebase Storage.
- The public Products page automatically reads published products from Firestore and displays them using the existing catalogue card style.
- Public customers can read products but cannot create/edit/delete them.
- Do not put passwords or Firebase Admin private keys in this website.

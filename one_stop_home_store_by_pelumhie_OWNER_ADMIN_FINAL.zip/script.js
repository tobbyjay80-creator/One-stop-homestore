(() => {
  'use strict';

  const q = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const cfg = window.PELUMHIE_FIREBASE_CONFIG || {enabled:false};
  let live = false, fb = {}, currentUser = null, confirmationResult = null, unsubscribeChat = null;

  // Reveal animations — one pass only; no timers or recursive loops.
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const reveals = document.querySelectorAll('.reveal');
  if (reduceMotion || !('IntersectionObserver' in window)) reveals.forEach(x => x.classList.add('show'));
  else { const io = new IntersectionObserver(entries => entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('show'); io.unobserve(e.target); } }), {threshold:.12}); reveals.forEach(x => io.observe(x)); }

  async function initFirebase(){
    if (!cfg.enabled || !cfg.config || String(cfg.config.apiKey || '').startsWith('REPLACE')) return;
    try {
      const [app, auth, fs, storage] = await Promise.all([
        import('https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js'),
        import('https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js'),
        import('https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js'),
        import('https://www.gstatic.com/firebasejs/12.19.0/firebase-storage.js')
      ]);
      const firebaseApp = app.initializeApp(cfg.config);
      const authService = auth.getAuth(firebaseApp);
      fb = {app, auth, fs, storage, firebaseApp, authService, db: fs.getFirestore(firebaseApp), store: storage.getStorage(firebaseApp)};
      live = true;
      auth.onAuthStateChanged(authService, user => { currentUser = user; updateAccountUI(); if(q('privateChatWindow')) loadPrivateChat(); if(q('ownerGate')) loadOwner(); });
    } catch(err) {
      console.warn('Live backend could not initialize. Preview mode remains available.', err);
      live = false;
    }
  }

  function demoSession(){ try { return JSON.parse(sessionStorage.getItem('pelumhie_demo_user') || 'null'); } catch { return null; } }
  function setDemoSession(user){ sessionStorage.setItem('pelumhie_demo_user', JSON.stringify(user)); currentUser = user; updateAccountUI(); }
  function clearDemo(){ sessionStorage.removeItem('pelumhie_demo_user'); currentUser = null; updateAccountUI(); }
  function userLabel(){ return currentUser?.displayName || currentUser?.email || currentUser?.phoneNumber || 'Customer'; }
  function updateAccountUI(){
    const state = q('accountState');
    if(state) state.innerHTML = currentUser ? `<div class="logged-in"><b>Signed in as ${esc(userLabel())}</b><span>Your private requests and chat can now be connected to this account.</span><button id="logoutBtn" class="btn outline" type="button">Sign Out</button></div>` : '<div class="small">You are not signed in.</div>';
    const logout=q('logoutBtn'); if(logout) logout.onclick = async()=>{ if(live) await fb.auth.signOut(fb.authService); else clearDemo(); location.reload(); };
  }

  // Product search: customer's exact words are passed into the chosen image site.
  const productSearch=q('productSearch');
  if(productSearch){
    const btn=q('productSearchBtn'), engine=q('searchEngine');
    function go(){ const term=productSearch.value.trim(); if(!term){ productSearch.focus(); return; } const enc=encodeURIComponent(term); const urls={unsplash:`https://unsplash.com/s/photos/${enc}`,pexels:`https://www.pexels.com/search/${enc}/`,pixabay:`https://pixabay.com/images/search/${enc}/`}; window.open(urls[engine.value]||urls.unsplash,'_blank','noopener,noreferrer'); }
    btn?.addEventListener('click',go); productSearch.addEventListener('keydown',e=>{if(e.key==='Enter')go()});
  }

  // Brand gallery.
  const modal=q('brandModal');
  if(modal){
    const title=q('brandModalTitle'), desc=q('brandModalDesc'), results=q('brandResults');
    document.querySelectorAll('[data-brand]').forEach(card=>card.addEventListener('click',()=>{
      const brand=card.dataset.brand, e=encodeURIComponent(`${brand} products bags shoes clothing accessories`);
      title.textContent=`${brand} image gallery`;
      desc.textContent=`Open a picture search for ${brand}, download an image you are permitted to use, then send it to the store.`;
      results.innerHTML=[['Unsplash',`https://unsplash.com/s/photos/${e}`],['Pexels',`https://www.pexels.com/search/${e}/`],['Pixabay',`https://pixabay.com/images/search/${e}/`]].map(x=>`<div class="brand-result"><b>${esc(x[0])}</b><p class="small">Search ${esc(brand)} images</p><a class="btn outline" target="_blank" rel="noopener noreferrer" href="${x[1]}">View Pictures ↗</a></div>`).join('');
      modal.classList.add('open'); modal.setAttribute('aria-hidden','false');
    }));
    const close=()=>{modal.classList.remove('open');modal.setAttribute('aria-hidden','true')}; q('brandModalClose')?.addEventListener('click',close); modal.addEventListener('click',e=>{if(e.target===modal)close()}); document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
  }

  // Product request form. Live mode uploads the image to Firebase Storage; preview mode keeps only local metadata.
  const requestForm=q('requestForm');
  if(requestForm){
    const file=q('requestImage'), preview=q('requestPreview'), status=q('requestStatus');
    file?.addEventListener('change',()=>{ const f=file.files[0]; if(!f){preview.style.display='none';return;} const ok=['image/jpeg','image/png','image/webp'].includes(f.type)&&f.size<=5*1024*1024; if(!ok){file.value='';preview.style.display='none';status.textContent='Please choose a JPG, PNG or WebP image up to 5MB.';status.style.display='block';return;} preview.src=URL.createObjectURL(f);preview.style.display='block';status.style.display='none'; });
    requestForm.addEventListener('submit',async e=>{
      e.preventDefault(); const desc=q('requestDescription').value.trim(), f=file?.files?.[0]; if(!desc&&!f){status.textContent='Please describe the product or upload a picture.';status.style.display='block';return;}
      try{
        let imageUrl='';
        if(live){
          if(!currentUser){status.textContent='Please sign in before sending a live product request.';status.style.display='block';return;}
          if(f){ const ref=fb.storage.ref(fb.store,`product-requests/${currentUser.uid}/${Date.now()}-${f.name.replace(/[^a-zA-Z0-9._-]/g,'_')}`); await fb.storage.uploadBytes(ref,f,{contentType:f.type}); imageUrl=await fb.storage.getDownloadURL(ref); }
          await fb.fs.addDoc(fb.fs.collection(fb.db,'requests'),{userId:currentUser.uid,email:currentUser.email||'',description:desc,imageUrl,createdAt:fb.fs.serverTimestamp()});
          status.textContent='Request sent securely to the store inbox.';
        } else {
          const old=JSON.parse(localStorage.getItem('pelumhie_requests')||'[]'); old.unshift({id:Date.now(),description:desc,imageName:f?.name||'',created:new Date().toISOString()}); localStorage.setItem('pelumhie_requests',JSON.stringify(old.slice(0,20)));
          status.textContent='Preview request saved on this device. Connect Firebase for the owner to receive it online.';
        }
        status.style.display='block';
        const msg=`Hello ONE-STOP HOME STORE BY PELUMHIE, I want to find a product.\n\n${desc||'I have a product picture.'}${f?`\n\nPicture: ${f.name}`:''}`;
        const wa=q('requestWhatsApp'); if(wa){wa.href='https://wa.me/2348104204939?text='+encodeURIComponent(msg);wa.classList.remove('hidden');}
      }catch(err){status.textContent='The request could not be sent. Please try again or use WhatsApp.';status.style.display='block';}
    });
  }

  // Account page.
  const emailForm=q('emailAuthForm');
  if(emailForm){
    let mode='signin';
    const tabs=document.querySelectorAll('[data-auth-tab]');
    tabs.forEach(t=>t.addEventListener('click',()=>{tabs.forEach(x=>x.classList.remove('active'));t.classList.add('active');mode=t.dataset.authTab;q('emailAuthText').textContent=mode==='signup'?'Create Account with Email':'Sign In with Email';}));
    emailForm.addEventListener('submit',async e=>{
      e.preventDefault(); const email=q('authEmail').value.trim(), password=q('authPassword').value; const notice=q('authNotice');
      if(!email || password.length<6)return;
      if(live){ try { const fn=mode==='signup'?fb.auth.createUserWithEmailAndPassword:fb.auth.signInWithEmailAndPassword; await fn(fb.authService,email,password); notice.textContent=mode==='signup'?'Account created successfully.':'Signed in successfully.'; } catch(err){ notice.textContent=err.message.replace('Firebase: ',''); } }
      else { setDemoSession({email,displayName:email.split('@')[0],demo:true}); notice.textContent='Preview account created. For a real secure account, connect the supplied Firebase configuration before launch.'; updateAccountUI(); }
    });
    q('googleAuth')?.addEventListener('click',async()=>{
      const notice=q('authNotice'); if(!live){notice.textContent='Google sign-in is ready in the interface, but it needs your Firebase project configuration and Google provider enabled.';return;} try{await fb.auth.signInWithPopup(fb.authService,new fb.auth.GoogleAuthProvider());}catch(err){notice.textContent=err.message.replace('Firebase: ','');}});
    q('phoneAuth')?.addEventListener('click',()=>{q('phoneBox')?.classList.toggle('hidden');});
    q('sendOtp')?.addEventListener('click',async()=>{
      const notice=q('authNotice'), phone=q('phoneNumber').value.trim(); if(!phone)return;
      if(!live){notice.textContent='Phone OTP is ready in the interface, but it needs Firebase Phone Authentication and a reCAPTCHA setup.';return;}
      try{ if(!window.__pelumhieRecaptcha) window.__pelumhieRecaptcha=new fb.auth.RecaptchaVerifier(fb.authService,'recaptcha-container',{size:'normal'}); confirmationResult=await fb.auth.signInWithPhoneNumber(fb.authService,phone,window.__pelumhieRecaptcha); q('otpBox').classList.remove('hidden'); notice.textContent='OTP sent. Enter the code you received.'; }catch(err){notice.textContent=err.message.replace('Firebase: ','');}
    });
    q('verifyOtp')?.addEventListener('click',async()=>{const code=q('otpCode').value.trim(),notice=q('authNotice'); if(!confirmationResult){notice.textContent='Send the OTP first.';return;} try{await confirmationResult.confirm(code);notice.textContent='Phone verified and signed in.';}catch(err){notice.textContent=err.message.replace('Firebase: ','');}});
    updateAccountUI();
  }

  // Private buyer chat. Live mode uses /chats/{uid}/messages and an owner-only inbox. Preview uses sessionStorage.
  const privateWindow=q('privateChatWindow'), privateForm=q('privateChatForm');
  async function loadPrivateChat(){
    if(!privateWindow)return;
    if(!live){ const demo=JSON.parse(sessionStorage.getItem('pelumhie_private_chat')||'[]'); renderMessages(privateWindow,demo); return; }
    if(!currentUser){ privateWindow.innerHTML='<div class="bubble owner">Please sign in to open your private conversation.</div>'; q('chatStatus').textContent='Sign in is required for the live private chat.'; return; }
    if(unsubscribeChat)unsubscribeChat();
    const ref=fb.fs.collection(fb.db,'chats',currentUser.uid,'messages');
    unsubscribeChat=fb.fs.onSnapshot(fb.fs.query(ref,fb.fs.orderBy('createdAt','asc')),snap=>{const arr=snap.docs.map(d=>({id:d.id,...d.data()}));renderMessages(privateWindow,arr);});
    q('chatStatus').textContent='Private live chat is connected. Only this buyer and the authorised owner should be able to access it.';
  }
  function renderMessages(el,msgs){ el.innerHTML=msgs.length?msgs.map(m=>`<div class="bubble ${m.role==='owner'?'owner':'customer'}">${esc(m.text)}<div class="small" style="margin-top:4px;opacity:.7">${m.createdAt?.toDate?m.createdAt.toDate().toLocaleString():new Date(m.time||Date.now()).toLocaleString()}</div></div>`).join(''):'<div class="bubble owner">Hello! Tell us what you need and we will reply privately.</div>';el.scrollTop=el.scrollHeight; }
  privateForm?.addEventListener('submit',async e=>{
    e.preventDefault(); const input=q('privateChatInput'), text=input.value.trim(); if(!text)return;
    if(live){ if(!currentUser){q('chatStatus').textContent='Please sign in first.';return;} try{await fb.fs.addDoc(fb.fs.collection(fb.db,'chats',currentUser.uid,'messages'),{role:'customer',text,userId:currentUser.uid,createdAt:fb.fs.serverTimestamp()}); await fb.fs.setDoc(fb.fs.doc(fb.db,'chatIndex',currentUser.uid),{userId:currentUser.uid,email:currentUser.email||'',displayName:userLabel(),updatedAt:fb.fs.serverTimestamp()},{merge:true});input.value='';}catch(err){q('chatStatus').textContent='Message could not be sent. Please try again.';} }
    else {const msgs=JSON.parse(sessionStorage.getItem('pelumhie_private_chat')||'[]');msgs.push({role:'customer',text,time:Date.now()});sessionStorage.setItem('pelumhie_private_chat',JSON.stringify(msgs.slice(-80)));input.value='';renderMessages(privateWindow,msgs);q('chatStatus').textContent='Preview private chat saved only in this browser session.';}
  });
  if(privateWindow) { currentUser=live?currentUser:demoSession(); setTimeout(loadPrivateChat,50); }

  // Customer reviews.
  const reviewForm=q('reviewForm'), reviewsList=q('reviewsList');
  function renderReviews(items){ if(!reviewsList)return; reviewsList.innerHTML=items.length?items.map(r=>`<article class="review-card"><div class="review-stars">${'★'.repeat(Math.max(1,Math.min(5,Number(r.rating)||5)))}${'☆'.repeat(5-Math.max(1,Math.min(5,Number(r.rating)||5)))}</div><p>${esc(r.text)}</p><b>${esc(r.displayName||'Customer')}</b><span class="small">${r.time?new Date(r.time).toLocaleDateString():''}</span></article>`).join(''):'<div class="empty-state">Be the first customer to leave a comment.</div>'; }
  function localReviews(){try{return JSON.parse(localStorage.getItem('pelumhie_reviews')||'[]')}catch{return[]}}
  renderReviews(localReviews());
  reviewForm?.addEventListener('submit',async e=>{
    e.preventDefault(); const text=q('reviewText').value.trim(), rating=Number(q('reviewRating').value), status=q('reviewStatus'); if(!text)return;
    if(live){if(!currentUser){status.textContent='Please sign in before posting a review.';status.style.display='block';return;} try{await fb.fs.addDoc(fb.fs.collection(fb.db,'reviews'),{userId:currentUser.uid,displayName:userLabel(),rating,text,createdAt:fb.fs.serverTimestamp()});status.textContent='Your comment was posted.';}catch(err){status.textContent='Your comment could not be posted yet.';} }
    else {const arr=localReviews();arr.unshift({rating,text,displayName:userLabel(),time:Date.now()});localStorage.setItem('pelumhie_reviews',JSON.stringify(arr.slice(0,20)));renderReviews(arr);status.textContent='Preview comment saved on this browser. Connect Firebase for shared customer comments.';}
    status.style.display='block';q('reviewText').value='';
  });
  async function loadLiveReviews(){ if(!live || !reviewsList)return; try{const snap=await fb.fs.getDocs(fb.fs.query(fb.fs.collection(fb.db,'reviews'),fb.fs.orderBy('createdAt','desc')));renderReviews(snap.docs.map(d=>{const x=d.data();return {...x,time:x.createdAt?.toDate?.().getTime()||Date.now()};}));}catch(e){} }

  // Owner inbox.
  async function loadOwner(){
    const gate=q('ownerStatus'), inbox=q('ownerInbox'); if(!gate)return;
    if(!live){gate.textContent='Preview mode: connect Firebase and set ownerUid in firebase-config.js to activate the real owner inbox.';return;}
    if(!currentUser || currentUser.uid!==cfg.ownerUid){gate.textContent='Owner access denied. Sign in with the configured owner account.';return;}
    gate.textContent='Owner verified.'; inbox.classList.remove('hidden');
    const list=q('ownerConversationList');
    try{const snap=await fb.fs.getDocs(fb.fs.query(fb.fs.collection(fb.db,'chatIndex'),fb.fs.orderBy('updatedAt','desc'))); list.innerHTML=snap.docs.map(d=>{const x=d.data();return `<button class="conversation-item" data-user-id="${esc(x.userId)}"><b>${esc(x.displayName||x.email||'Customer')}</b><span>${esc(x.email||'')}</span><small>Open private conversation →</small></button>`}).join('')||'<div class="empty-state">No customer conversations yet.</div>'; list.querySelectorAll('[data-user-id]').forEach(b=>b.onclick=()=>openOwnerConversation(b.dataset.userId));}catch(err){list.innerHTML='<div class="empty-state">Owner inbox could not load. Check Firestore rules.</div>';}
  }
  async function openOwnerConversation(uid){
    q('ownerConversationList').classList.add('hidden');q('ownerConversation').classList.remove('hidden');const win=q('ownerChatWindow');
    if(unsubscribeChat)unsubscribeChat(); const ref=fb.fs.collection(fb.db,'chats',uid,'messages'); unsubscribeChat=fb.fs.onSnapshot(fb.fs.query(ref,fb.fs.orderBy('createdAt','asc')),snap=>renderMessages(win,snap.docs.map(d=>d.data()))); q('ownerChatForm').dataset.userId=uid;
  }
  q('backToInbox')?.addEventListener('click',()=>{q('ownerConversation').classList.add('hidden');q('ownerConversationList').classList.remove('hidden');loadOwner();});
  q('ownerChatForm')?.addEventListener('submit',async e=>{e.preventDefault();const uid=e.currentTarget.dataset.userId,text=q('ownerChatInput').value.trim();if(!uid||!text||!live)return;await fb.fs.addDoc(fb.fs.collection(fb.db,'chats',uid,'messages'),{role:'owner',text,userId:uid,ownerUid:currentUser.uid,createdAt:fb.fs.serverTimestamp()});await fb.fs.setDoc(fb.fs.doc(fb.db,'chatIndex',uid),{updatedAt:fb.fs.serverTimestamp()},{merge:true});q('ownerChatInput').value='';});


  // Local real-product catalogue search/filter.
  const catalogGrid=q('catalogGrid');
  if(catalogGrid){
    const items=[...catalogGrid.querySelectorAll('.catalog-item')], search=q('catalogSearch'), select=q('catalogCategory'), count=q('catalogCount');
    [...new Set(items.map(x=>x.dataset.category).filter(Boolean))].sort().forEach(c=>{const o=document.createElement('option');o.value=c;o.textContent=c.replace(/\b\w/g,m=>m.toUpperCase());select.appendChild(o);});
    function filterCatalogue(){
      const term=(search.value||'').trim().toLowerCase(), cat=select.value;
      let shown=0;
      items.forEach(x=>{const okT=!term||x.dataset.name.includes(term)||x.dataset.category.includes(term),okC=cat==='all'||x.dataset.category===cat,show=okT&&okC;x.style.display=show?'flex':'none';if(show)shown++;});
      count.textContent=`${shown} product${shown===1?'':'s'} shown`;
    }
    search.addEventListener('input',filterCatalogue);select.addEventListener('change',filterCatalogue);filterCatalogue();
  }

  initFirebase().then(()=>{ if(!live) currentUser=demoSession(); updateAccountUI(); if(q('privateChatWindow'))loadPrivateChat(); if(q('ownerGate'))loadOwner(); if(reviewsList)loadLiveReviews(); });
})();
